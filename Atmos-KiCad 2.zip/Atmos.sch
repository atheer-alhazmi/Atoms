EESchema Schematic File Version 4
LIBS:Atmos-cache
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
encoding utf-8
Sheet 1 1
Title "Atmos smart window"
$EndDescr
$Comp
L Atmos:Part0 U1
U 1 1 66000000
P 2000 1200
F 0 "U1" H 2000 970 50  0000 C CNN
F 1 "Arduino Uno R3 (USB power)" H 2000 1080 50  0000 C CNN
	1 2000 1200
	1 0 0 -1
$EndComp
Wire Wire Line
	2650 1200 3050 1200
Text Label 3050 1200 0 50 ~ 0
V5
Wire Wire Line
	2650 1300 3050 1300
Text Label 3050 1300 0 50 ~ 0
GND
Wire Wire Line
	2650 1400 3050 1400
Text Label 3050 1400 0 50 ~ 0
RAIN
Wire Wire Line
	2650 1500 3050 1500
Text Label 3050 1500 0 50 ~ 0
WIND
Wire Wire Line
	2650 1600 3050 1600
Text Label 3050 1600 0 50 ~ 0
IN_DATA
Wire Wire Line
	2650 1700 3050 1700
Text Label 3050 1700 0 50 ~ 0
OUT_DATA
Wire Wire Line
	2650 1800 3050 1800
Text Label 3050 1800 0 50 ~ 0
SERVO
Wire Wire Line
	2650 1900 3050 1900
Text Label 3050 1900 0 50 ~ 0
SDA
Wire Wire Line
	2650 2000 3050 2000
Text Label 3050 2000 0 50 ~ 0
SCL
$Comp
L Atmos:Part1 U2
U 1 1 66000001
P 7000 1200
F 0 "U2" H 7000 970 50  0000 C CNN
F 1 "FC-37 + comparator module" H 7000 1080 50  0000 C CNN
	1 7000 1200
	1 0 0 -1
$EndComp
Wire Wire Line
	7650 1200 8050 1200
Text Label 8050 1200 0 50 ~ 0
V5
Wire Wire Line
	7650 1300 8050 1300
Text Label 8050 1300 0 50 ~ 0
GND
Wire Wire Line
	7650 1400 8050 1400
Text Label 8050 1400 0 50 ~ 0
RAIN
NoConn ~ 7650 1500
$Comp
L Atmos:Part2 SW1
U 1 1 66000002
P 12000 1200
F 0 "SW1" H 12000 970 50  0000 C CNN
F 1 "Anemometer (reed pulse)" H 12000 1080 50  0000 C CNN
	1 12000 1200
	1 0 0 -1
$EndComp
Wire Wire Line
	12650 1200 13050 1200
Text Label 13050 1200 0 50 ~ 0
WIND
Wire Wire Line
	12650 1300 13050 1300
Text Label 13050 1300 0 50 ~ 0
GND
$Comp
L Atmos:Part3 U3
U 1 1 66000003
P 2000 3600
F 0 "U3" H 2000 3370 50  0000 C CNN
F 1 "Indoor DHT22" H 2000 3480 50  0000 C CNN
	1 2000 3600
	1 0 0 -1
$EndComp
Wire Wire Line
	2650 3600 3050 3600
Text Label 3050 3600 0 50 ~ 0
V5
Wire Wire Line
	2650 3700 3050 3700
Text Label 3050 3700 0 50 ~ 0
IN_DATA
NoConn ~ 2650 3800
Wire Wire Line
	2650 3900 3050 3900
Text Label 3050 3900 0 50 ~ 0
GND
$Comp
L Atmos:Part4 U4
U 1 1 66000004
P 7000 3600
F 0 "U4" H 7000 3370 50  0000 C CNN
F 1 "Outdoor DHT22" H 7000 3480 50  0000 C CNN
	1 7000 3600
	1 0 0 -1
$EndComp
Wire Wire Line
	7650 3600 8050 3600
Text Label 8050 3600 0 50 ~ 0
V5
Wire Wire Line
	7650 3700 8050 3700
Text Label 8050 3700 0 50 ~ 0
OUT_DATA
NoConn ~ 7650 3800
Wire Wire Line
	7650 3900 8050 3900
Text Label 8050 3900 0 50 ~ 0
GND
$Comp
L Atmos:Part5 U5
U 1 1 66000005
P 12000 3600
F 0 "U5" H 12000 3370 50  0000 C CNN
F 1 "BH1750 breakout *" H 12000 3480 50  0000 C CNN
	1 12000 3600
	1 0 0 -1
$EndComp
Wire Wire Line
	12650 3600 13050 3600
Text Label 13050 3600 0 50 ~ 0
V5
Wire Wire Line
	12650 3700 13050 3700
Text Label 13050 3700 0 50 ~ 0
GND
Wire Wire Line
	12650 3800 13050 3800
Text Label 13050 3800 0 50 ~ 0
SDA
Wire Wire Line
	12650 3900 13050 3900
Text Label 13050 3900 0 50 ~ 0
SCL
Wire Wire Line
	12650 4000 13050 4000
Text Label 13050 4000 0 50 ~ 0
GND
$Comp
L Atmos:Part6 DS1
U 1 1 66000006
P 2000 6000
F 0 "DS1" H 2000 5770 50  0000 C CNN
F 1 "I2C LCD 16 x 2" H 2000 5880 50  0000 C CNN
	1 2000 6000
	1 0 0 -1
$EndComp
Wire Wire Line
	2650 6000 3050 6000
Text Label 3050 6000 0 50 ~ 0
V5
Wire Wire Line
	2650 6100 3050 6100
Text Label 3050 6100 0 50 ~ 0
GND
Wire Wire Line
	2650 6200 3050 6200
Text Label 3050 6200 0 50 ~ 0
SDA
Wire Wire Line
	2650 6300 3050 6300
Text Label 3050 6300 0 50 ~ 0
SCL
$Comp
L Atmos:Part7 M1
U 1 1 66000007
P 7000 6000
F 0 "M1" H 7000 5770 50  0000 C CNN
F 1 "MG996R" H 7000 5880 50  0000 C CNN
	1 7000 6000
	1 0 0 -1
$EndComp
Wire Wire Line
	7650 6000 8050 6000
Text Label 8050 6000 0 50 ~ 0
SERVO
Wire Wire Line
	7650 6100 8050 6100
Text Label 8050 6100 0 50 ~ 0
MOTOR_5V
Wire Wire Line
	7650 6200 8050 6200
Text Label 8050 6200 0 50 ~ 0
GND
$Comp
L Atmos:Part8 J1
U 1 1 66000008
P 12000 6000
F 0 "J1" H 12000 5770 50  0000 C CNN
F 1 "Regulated servo supply" H 12000 5880 50  0000 C CNN
	1 12000 6000
	1 0 0 -1
$EndComp
Wire Wire Line
	12650 6000 13050 6000
Text Label 13050 6000 0 50 ~ 0
MOTOR_5V
Wire Wire Line
	12650 6100 13050 6100
Text Label 13050 6100 0 50 ~ 0
GND
$Comp
L Atmos:Part9 R1
U 1 1 66000009
P 2000 8400
F 0 "R1" H 2000 8170 50  0000 C CNN
F 1 "4.7k pull-up" H 2000 8280 50  0000 C CNN
	1 2000 8400
	1 0 0 -1
$EndComp
Wire Wire Line
	2650 8400 3050 8400
Text Label 3050 8400 0 50 ~ 0
V5
Wire Wire Line
	2650 8500 3050 8500
Text Label 3050 8500 0 50 ~ 0
IN_DATA
$Comp
L Atmos:Part10 R2
U 1 1 6600000A
P 7000 8400
F 0 "R2" H 7000 8170 50  0000 C CNN
F 1 "4.7k pull-up" H 7000 8280 50  0000 C CNN
	1 7000 8400
	1 0 0 -1
$EndComp
Wire Wire Line
	7650 8400 8050 8400
Text Label 8050 8400 0 50 ~ 0
V5
Wire Wire Line
	7650 8500 8050 8500
Text Label 8050 8500 0 50 ~ 0
OUT_DATA
$Comp
L Atmos:Part11 R3
U 1 1 6600000B
P 12000 8400
F 0 "R3" H 12000 8170 50  0000 C CNN
F 1 "10k pull-up" H 12000 8280 50  0000 C CNN
	1 12000 8400
	1 0 0 -1
$EndComp
Wire Wire Line
	12650 8400 13050 8400
Text Label 13050 8400 0 50 ~ 0
V5
Wire Wire Line
	12650 8500 13050 8500
Text Label 13050 8500 0 50 ~ 0
WIND
Text Notes 1000 10200 0 55 ~ 0
* Use a BH1750 breakout rated for 5 V power AND 5 V I2C logic (level shifting). Bare BH1750 requires a 3.3 V interface.
Text Notes 1000 10420 0 55 ~ 0
Wind input assumes a dry-contact pulse anemometer. Determine speed calibration from its datasheet. FC-37 plate connects to its comparator board.
Text Notes 1000 10640 0 55 ~ 0
USB powers the Uno and sensors. Use a separate regulated 5 V supply sized for servo stall current. Join grounds only.
$EndSCHEMATC
